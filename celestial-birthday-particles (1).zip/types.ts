
export enum ParticleTemplate {
  HEART = 'HEART',
  FLOWER = 'FLOWER',
  FIREWORKS = 'FIREWORKS',
  BLAST = 'BLAST',
  DESIGN = 'DESIGN',
  SPIRAL = 'SPIRAL',
  CAKE = 'CAKE'
}

export enum BirthdayStage {
  IDLE = 'IDLE',
  DYNAMIC_FLOW = 'DYNAMIC_FLOW',
  CAKE_TIME = 'CAKE_TIME',
  BLOW_MESSAGE = 'BLOW_MESSAGE',
  BIRTHDAY_BLAST = 'BIRTHDAY_BLAST',
  FINAL_WISH = 'FINAL_WISH'
}

export interface GestureState {
  gesture: string;
  template: ParticleTemplate;
  color: string;
  expansion: number;
}

export interface ParticleConfig {
  count: number;
  size: number;
  color: string;
  opacity: number;
}
